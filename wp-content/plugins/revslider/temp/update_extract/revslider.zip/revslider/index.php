<?php

/**

 * Plugin Name:  WordPress Folder

 * Version: 1.0

 * Author: Niceman

 * License: GPLv2

 */

?>
<!-- lalalala -->
